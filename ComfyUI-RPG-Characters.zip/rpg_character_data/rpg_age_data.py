AGE_DATA = {
    "Childhood": {"prompt": "In their Childhood", "negative_prompt": "Adult like, teenager, old age"},
    "Adolescent": {"prompt": "In their Adolescent", "negative_prompt": "Adult like, teenager, old age"},
    "Adult": {"prompt": "In their Adulthood", "negative_prompt": "Child like, kid, kids, old age"},
    "Early Adult": {"prompt": "In their Early Adulthood", "negative_prompt": "Child like, kid, kids, old age"},
    "Mid Adult": {"prompt": "In their Mid Adulthood", "negative_prompt": "Child like, kid, kids"},
    "Late Adult": {"prompt": "In their Late Adulthood", "negative_prompt": "Child like, kid, kids, teenager"},
    "Senior": {"prompt": "In their Senior years", "negative_prompt": "Child like, kid, kids, teenager"},
    "Early Senior": {"prompt": "In their Early Senior years", "negative_prompt": "Child like, kid, kids, teenager"},
    "Late Senior": {"prompt": "In their Late Senior years", "negative_prompt": "Child like, kid, kids, teenager"},
}